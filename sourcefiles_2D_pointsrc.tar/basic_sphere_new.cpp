//example calculation: 2D - calculation of a dielectric cylinder in vacuum
//using a non-uniform grid near the sphere, i.e. transform the eps an mu
//according to S. Johnson's Notes on his MIT lecture
//By default, the refractive index of the cylinder is 1, so to actually see
//something other than travelling waves in a coordinate-transformed domain,
//change this to a meaningful value

//This example was written by fesc3555
//Felix Schwarz
//Technische Universität Ilmenau
//FG Theoretische Physik I

//feel free to use and alter it or copy from it
//beware that parts of the code in material.hpp are just copied
//from the MEEP source and probably fall under the respective
//license agreement.


#include<meep.hpp>
#include<iostream>
#include<vector>
#include "resolution_domain.hpp"
#include "material.hpp"
using namespace meep;
using namespace std;

//distance unit: micrometer
const double sphere_radius=1.;
const double cell_size=5*sphere_radius;
const double pml_thickness=0.7;
const vec center=vec(pml_thickness + cell_size/2,pml_thickness + cell_size/2);

const double fs=0.3;

//dielectric function constants
const double eps_d=1.0;
//const double eps_d=4.0;


int main(int argc, char **argv){
  initialize mpi(argc,argv);
  const double amicron=60;
  const grid_volume vol=vol2d(2*center.x(),2*center.y(),amicron);

  //the boundaries of the different resoluition domains
  vector<double> res_bound(2); //isotropic, no need for more than one vector
  res_bound[0]=center.x()-1.1*sphere_radius;
  res_bound[1]=center.x()+1.1*sphere_radius;

  //the (inverse) stretch factors of the resolution domains.
  //.25 meaning a fourfold coordinate stretch
  vector<double> stretch(3); //isotropic, no need for more than one vector
  stretch[0]=0.25;
  stretch[1]=1.;
  stretch[2]=0.25;

  //defined in resolution_domain.hpp and .cpp :
  Cresolution_domain_2D resolution_domain(res_bound,res_bound,stretch,stretch,center);

  //defined in material.hpp and .cpp :
  Ceps eps(resolution_domain,sphere_radius,eps_d,center);
  double courant = 0.5; //standard Courant number

  structure s(vol,eps,pml(pml_thickness),identity(),0,courant,true,
	      DEFAULT_SUBPIXEL_TOL,100);
  
  fields f(&s);

  const double freq_res=0.4/fs;
  const double tau=12*fs;
  const double sigma=tau/(2.0*sqrt(2.0*log(2.0)));
  
  gaussian_src_time src(freq_res,sigma,0.0*sigma,10.0*sigma);
  f.add_point_source(Ex,src,vol.center()+vec(3*sphere_radius,3*sphere_radius)/sqrt(2.));
  f.output_hdf5(Dielectric,vol.surroundings());
  
  cout << "timestep dt: " << f.dt << endl;
  cout << "total time to do: " << f.last_source_time() << endl;

  int counter(0);
  while (f.time() < f.last_source_time()){
    f.step();
    if (counter%200==0){
      f.output_hdf5(Ex,vol.surroundings());
      f.output_hdf5(Hz,vol.surroundings());
    }
    counter++;
  }

}
