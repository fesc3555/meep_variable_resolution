//example calculation: 3D - calculation of a dielectric cylinder in vacuum
//using a non-uniform grid near the sphere, i.e. transform the eps an mu
//according to S. Johnson's Notes on his MIT lecture
//By default, the refractive index of the cylinder is 1, so to actually see
//something other than travelling waves in a coordinate-transformed domain,
//change this to a meaningful value

//This example was written by fesc3555
//Felix Schwarz
//Technische Universität Ilmenau
//FG Theoretische Physik I

//feel free to use and alter it or copy from it.
//Be aware that parts of the code in material.hpp are just copied
//from the MEEP source and probably fall under the respective
//license agreement.

#include<meep.hpp>
#include<iostream>
#include<vector>
#include "resolution_domain.hpp"
#include "material.hpp"

#include<functional>
using namespace meep;
using namespace std;


complex<double> amp_phase(const vec&p, const double k_x){
  return exp(complex<double>(0.,1.)*k_x*p.x());
}

complex<double> multiply_wrapper(function<double(const vec&)> amp,
				 function<complex<double>(const vec&)> phase,
				 const vec &p){
  return amp(p)*phase(p);
  //return phase(p);
}

int main(int argc, char **argv){
  initialize mpi(argc,argv);

  //example calculation: 3D - calculation of a dielectric sphere in vacuum
  //using a non-uniform grid near the sphere, i.e. transform the eps an mu
  //according to Johnsons Paper using the Jacobian
  
  //distance unit: micrometer
  const double sphere_radius=1.;
  const double lambda=0.5;
  const double cell_size=3.5*sphere_radius;
  const double pml_thickness=0.1;
  const vec center=vec(pml_thickness + cell_size/2.,
		       pml_thickness + cell_size/2.,
		       pml_thickness + cell_size/2.);
  
  const double fs=0.3;
  
  //dielectric function constants
  const double eps_d=4.0;
  const double amicron=40;
  //const double amicron=30;

  cout << "number of pixel in one direction: " << 2*center.x()*amicron << endl;

  const grid_volume vol=vol3d(2*center.x(),2*center.y(),2*center.z(),amicron);
							      
  vector<double> res_bound(2); //isotropic
  res_bound[0]=center.x()-1.1*sphere_radius;
  res_bound[1]=center.x()+1.1*sphere_radius;

  vector<double> stretch(3); //isotropic
  stretch[0]=.25;
  stretch[1]=1.;
  stretch[2]=.25;
  
  Cresolution_domain_3D resolution_domain(res_bound,res_bound,res_bound,
					  stretch,stretch,stretch,
					  center);
  
  Ceps eps(resolution_domain,sphere_radius,eps_d,center);
  double courant = 0.5; //standard Courant number
  structure s(vol,eps,pml(pml_thickness),identity(),0,courant,true,
	      10*DEFAULT_SUBPIXEL_TOL,50);//DEFAULT_SUBPIXEL_MAXEVAL/10000);
  
  fields f(&s);
  
  //  const double freq_res=0.62/fs; //620 THz, omega surface_plasmon
  const double freq = fs/(lambda);
  const double tau=6*fs;
  const double sigma=tau/(2.0*sqrt(2.0*log(2.0)));

  const component src_comp=Hx;

  function<double(const vec&)>
    amplitudefunc(bind(&Cresolution_domain_3D::J_multiplicator,
		       ref(resolution_domain),placeholders::_1,
		       component_direction(src_comp)));
  
  gaussian_src_time src(freq,sigma,0.0*sigma,10.0*sigma);
  
  
  f.add_point_source(src_comp,src,vec(1.1*pml_thickness,1.1*pml_thickness,1.1*pml_thickness));
  f.output_hdf5(Dielectric,vol.surroundings());
  
  cout << "timestep dt: " << f.dt << endl;
  cout << "total time to do: " << f.last_source_time() << endl;

  int counter(0);

  int every_N_pic = floor(0.5/(freq*f.dt));
  cout << "every N images we make one pic: " << every_N_pic << endl;
  
  while (f.time() < f.last_source_time() + 4.){
    f.step();
    if (counter%every_N_pic==0)
      f.output_hdf5(Ey,vol.surroundings());
    if (counter%every_N_pic==0)
      f.output_hdf5(Hx,vol.surroundings());
    counter++;
  }
  
}
