//libraries needed: meep (header meep.hpp)
#include<meep.hpp>
#include<iostream>
#include<fstream>
#include<vector>
#include "resolution_domain.hpp"
#include "sphere-quad.h"

#include<functional>
using namespace meep;
using namespace std;

double abs2D(const vec &a){return sqrt(a.x()*a.x()+a.y()*a.y());}
static vec sphere_pt(const vec &cent, double R, int n, double &weight) {
  weight = sphere_quad[1][n][3];
  vec pt(sphere_quad[1][n][0], sphere_quad[1][n][1]);
  return cent + pt * R;
}

class Ceps : public material_function
{
public:
  Ceps(const Cresolution_domain_2D _res_dom, const double _sphere_rad,
       const double _eps_sphere, const double _sigma, const vec &_center):
    res_dom(_res_dom),
    sphere_rad(_sphere_rad),eps_sphere(_eps_sphere),sigma(_sigma),
    center(_center){}
  virtual bool has_mu(){return true;}
  virtual double chi1p1(field_type ft, const vec &r){
    if(ft == E_stuff && abs2D(r-center) < sphere_rad) return eps_sphere;
    return 1.0;
  }
  void sigma_row(component c, double sigrow[3], const vec &p) {
    sigrow[0] = sigrow[1] = sigrow[2] = 0.0;
    if(abs2D(p-center) < sphere_rad) sigrow[component_index(c)] = sigma;
  }

  vec normal_vector_anis(field_type ft, const volume &v,const direction dir){
    vec gradient(zero_vec(v.dim));
    vec p(v.center());
    double R = v.diameter();
    for (int i = 0; i < num_sphere_quad[number_of_directions(v.dim)-1]; ++i) {
      double weight;
      vec pt = sphere_pt(p, R, i, weight);
      //probably only a good formula for diagonal chi1p1:
      gradient += (pt - p) * (weight * res_dom.chi1p1_multiplicator(pt,dir)*
			      chi1p1(ft,pt));
    }
    return gradient; 
  }
  
  virtual void eff_chi1inv_row(component c, double chi1inv_row[3], const volume &v,
			       double tol=DEFAULT_SUBPIXEL_TOL,
			       int maxeval=DEFAULT_SUBPIXEL_MAXEVAL){
    field_type ft = type(c);
    vec gradient(normal_vector_anis(ft, v,component_direction(c)));
    if (!maxeval || abs(gradient) < 1e-8 ){
    trivial:
      chi1inv_row[0] = chi1inv_row[1] = chi1inv_row[2] = 0.;
      //chi1pi = J*chi1p1*J'/det(J) boils down to just a factor for diagonal eps
      chi1inv_row[component_direction(c)]=
	1/(res_dom.chi1p1_multiplicator(v.center(),component_direction(c)) *
	   chi1p1(ft,v.center()));
      return;
    }
    double meps=1, minveps=1;
    vec d = v.get_max_corner() - v.get_min_corner();
    int ms = 10;
    double old_meps=0, old_minveps=0;
    int iter = 0;
    while ((fabs(meps-old_meps) > tol*old_meps) && (fabs(minveps-old_minveps) > tol*old_minveps)) {
      old_meps=meps; old_minveps=minveps;
      meps = minveps = 0;
      for (int j=0; j < ms; j++)
        for (int i=0; i < ms; i++) {
	  vec p=v.get_min_corner() + vec(i*d.x()/ms, j*d.y()/ms);
          double ep = res_dom.chi1p1_multiplicator(p,component_direction(c))*chi1p1(ft,p);
          if (ep < 0) {goto trivial;}
          meps += ep; minveps += 1/ep;
        }
      meps /= ms*ms;
      minveps /= ms*ms;
      ms *= 2;
      if (maxeval && (iter += ms*ms) >= maxeval) break;
    }
    double n[3] = {0,0,0};
    double nabsinv = 1.0/abs(gradient);
    LOOP_OVER_DIRECTIONS(gradient.dim, k)
      n[k%3] = gradient.in_direction(k) * nabsinv;

    /* get rownum'th row of effective tensor
       P * minveps + (I-P) * 1/meps = P * (minveps-1/meps) + I * 1/meps
       where I is the identity and P is the projection matrix
       P_{ij} = n[i] * n[j]. */
    int rownum = component_direction(c) % 3;
    for (int i=0; i<3; ++i)
      chi1inv_row[i] = n[rownum] * n[i] * (minveps - 1/meps);
    chi1inv_row[rownum] += 1/meps;
  }

private:
  Cresolution_domain_2D res_dom;
  double sphere_rad, eps_sphere, sigma;
  vec center;
};

complex<double> amp_phase(const vec&p, const double k_x){
  return exp(complex<double>(0.,1.)*k_x*p.x());
}

complex<double> multiply_wrapper(function<double(const vec&)> amp,
				 function<complex<double>(const vec&)> phase,
				 const vec &p){
  return amp(p)*phase(p);
  //return phase(p);
}

int main(int argc, char **argv){
  initialize mpi(argc,argv);
  //distance unit: microns
  
  const double sphere_radius=.2;

  const double amicron=500;
							      
  vector<double> stretch(3); //isotropic
  stretch[0]=.125;
  stretch[1]=1.;
  stretch[2]=.125;

  //distance unit: micrometer
  const double cell_size=2.6*sphere_radius + 4.*sphere_radius*stretch[0];
  const double pml_thickness=0.7*stretch[0];
  const vec center=vec(pml_thickness + cell_size/2,pml_thickness + cell_size/2);

  vector<double> res_bound(2); //isotropic
  res_bound[0]=center.x()-1.3*sphere_radius;
  res_bound[1]=center.x()+1.3*sphere_radius;
  
  const double fs=0.3;

  //dielectric function constants
  Cresolution_domain_2D resolution_domain(res_bound,res_bound,stretch,stretch,center);

  double eps_d(1.0), sigma_d(0.0), omega_drude(0.), gamma_drude(0.);
  
  const bool empty = false;
  
  if(!empty){ //full of metal
    //eps_d=4.;
    eps_d=9.0685;
    sigma_d=1.;
    omega_drude=2.1556/fs;
    gamma_drude=0.01836/fs;
  }
  
  Ceps eps(resolution_domain,sphere_radius,eps_d,sigma_d,center);
  double courant = 0.5; //standard Courant number

  const grid_volume vol=vol2d(2*center.x(),2*center.y(),amicron);
  structure s(vol,eps,pml(pml_thickness),identity(),0,courant,true,
	      DEFAULT_SUBPIXEL_TOL,100);//DEFAULT_SUBPIXEL_MAXEVAL/10000);
  // material functions
  lorentzian_susceptibility drude_sus(omega_drude, gamma_drude, true);
  s.add_susceptibility(eps,E_stuff,drude_sus);
  
  fields f(&s);

  //  const double freq_res=0.62/fs; //620 THz, omega surface_plasmon
  const double freq_res=0.5625/fs;
  const double tau=4*fs;
  const double sigma=tau/(2.0*sqrt(2.0*log(2.0)));

  const double theta = 90./360*2*pi;
  const double k_abs = freq_res*2*pi;
  const double k_x=cos(theta)*k_abs;

  const component src_comp=Hz;

  function<complex<double>(const vec&)> phasefunc(bind(amp_phase,placeholders::_1,k_x));
  function<double(const vec&)>
    amplitudefunc(bind(&Cresolution_domain_2D::J_multiplicator,
		       ref(resolution_domain),placeholders::_1,
		       component_direction(src_comp)));
  
  gaussian_src_time src(freq_res,sigma,0.0*sigma,10.0*sigma);
  const volume printvol(vec(pml_thickness,pml_thickness),
			center+center-vec(pml_thickness,pml_thickness));
  const volume srcvol(vec(0.,2.*center.y()-1.05*pml_thickness),
		      vec(2*center.x(),2.*center.y()-1.05*pml_thickness) );

  const double sb_hs=1.3*sphere_radius+1.9*sphere_radius*stretch[0]; //scatterbox half-size
  const volume scatterbox(center+vec(sb_hs,sb_hs),
			  center-vec(sb_hs,sb_hs) );
  const volume source_int(center+vec(-sb_hs,0.),
			  center+vec(sb_hs,0.));
  
  f.add_volume_source(src_comp,src,srcvol,
		      bind(multiply_wrapper,amplitudefunc,phasefunc,placeholders::_1),
		      1.0); //FIXME
  f.output_hdf5(Dielectric,vol.surroundings());

  int Nfreq=200;
  dft_flux srcflux=f.add_dft_flux_box(source_int,0.375/fs,0.75/fs,Nfreq);
  dft_flux myflux=f.add_dft_flux_box(scatterbox,0.375/fs,0.75/fs,Nfreq);
  dft_flux fluxplane=f.add_dft_flux_plane(source_int,0.375/fs,0.75/fs,Nfreq);
  if(!empty){
    myflux.load_hdf5(f,"oldflux.h5");
    myflux.scale_dfts(-1.0);
  }
  
  cout << "timestep dt: " << f.dt << endl;
  cout << "total time to do: " << f.last_source_time()+30*fs << endl;

  int every_N=floor(0.5/(freq_res*f.dt));

  int counter(0);
  while (f.time() < f.last_source_time()+30*fs){
    f.step();
    if (counter%every_N==0 && f.time() < f.last_source_time() + 2/freq_res)
      f.output_hdf5(Hz,vol.surroundings());
    if (counter%every_N==0 && f.time() < f.last_source_time() + 2/freq_res)
      f.output_hdf5(Ex,vol.surroundings());
    counter++;
  }

  double *flux=myflux.flux();
  double *sflux=srcflux.flux();
  double *pflux=fluxplane.flux();
  cout << sflux[99] << endl;
  if(empty){
    myflux.save_hdf5(f,"oldflux.h5");
    ofstream fout("flux_empty.dat");
    for(int i=0;i<Nfreq;++i){
      fout << flux[i] << "\t" << sflux[i] << "\t" << pflux[i] << "\n";
    }
    fout.close();
  }else{
    ofstream fout("flux_nanorod.dat");
    for(int i=0;i<Nfreq;++i){
      fout << flux[i] << "\t" << sflux[i] << "\t" << pflux[i] << "\n";
    }
    fout.close();
  }
  delete[] flux;
  delete[] sflux;
  delete[] pflux;
}
