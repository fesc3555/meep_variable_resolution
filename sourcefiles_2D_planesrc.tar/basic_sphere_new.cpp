//example calculation: 2D - calculation of a dielectric cylinder in vacuum
//using a non-uniform grid near the sphere, i.e. transform the eps an mu
//according to S. Johnson's Notes on his MIT lecture
//By default, the refractive index of the cylinder is 1, so to actually see
//something other than travelling waves in a coordinate-transformed domain,
//change this to a meaningful value

//This example was written by fesc3555
//Felix Schwarz
//Technische Universität Ilmenau
//FG Theoretische Physik I

//feel free to use and alter it or copy from it
//beware that parts of the code in material.hpp are just copied
//from the MEEP source and probably fall under the respective
//license agreement.

//BEWARE: this example needs some small alterations in the meep lib
//replace the function pointer in the add_volume_src function header
//by a std::function<complex<double>(const vec &)> object,
//or just use the meep.hpp and sources.cpp contained in this foulder
//and recompile meep
//Note that I won't update the file for future versions of meep and this
//only works at the time of this writing, October 2017.

#include<meep.hpp>
#include<iostream>
#include<vector>
#include "resolution_domain.hpp"
#include "material.hpp"

#include<functional>
using namespace meep;
using namespace std;

//distance unit: micrometer
const double sphere_radius=1.;
const double cell_size=5*sphere_radius;
const double pml_thickness=0.7;
const vec center=vec(pml_thickness + cell_size/2,pml_thickness + cell_size/2);

const double fs=0.3;

//dielectric function constants
const double eps_d=1.0;
//const double eps_d=4.0;



complex<double> amp_phase(const vec&p, const double k_x){
  return exp(complex<double>(0.,1.)*k_x*p.x());
}

complex<double> multiply_wrapper(function<double(const vec&)> amp,
				 function<complex<double>(const vec&)> phase,
				 const vec &p){
  return amp(p)*phase(p);
  //return phase(p);
}

int main(int argc, char **argv){
  initialize mpi(argc,argv);
  const double fs=0.5;
  const double amicron=60;
  //cout << center.x() << endl;
  const grid_volume vol=vol2d(2*center.x(),2*center.y(),amicron);
							      
  vector<double> res_bound(2); //isotropic
  res_bound[0]=center.x()-1.1*sphere_radius;
  res_bound[1]=center.x()+1.1*sphere_radius;


  vector<double> stretch(3); //isotropic
  stretch[0]=.25;
  stretch[1]=1.;
  stretch[2]=.25;

  Cresolution_domain_2D resolution_domain(res_bound,res_bound,
					  stretch,stretch,center);

  Ceps eps(resolution_domain,sphere_radius,eps_d,center);
  double courant = 0.5; //standard Courant number
  structure s(vol,eps,pml(pml_thickness),identity(),0,courant,true,
	      DEFAULT_SUBPIXEL_TOL,100);//DEFAULT_SUBPIXEL_MAXEVAL/10000);
  
  fields f(&s);

  const double freq_res=0.4/fs;
  const double tau=12*fs;
  const double sigma=tau/(2.0*sqrt(2.0*log(2.0)));

  //this was only tested for 90 degree incidence
  //if you wanted to implement this, you should probably transform the
  //k-vector in the different domains as well
  const double theta = 90./360*2*pi; //perpendicular for now
  const double k_abs = freq_res*2*pi;
  const double k_x=cos(theta)*k_abs;

  const component source_component(Ez);

  //phase function of the source: important for non-perpendicular incidence
  function<complex<double>(const vec&)> phasefunc(bind(amp_phase,placeholders::_1,k_x));

  //amplitude function of the source: important for different resolution domains
  function<double(const vec&)>
    amplitudefunc(bind(&Cresolution_domain_2D::J_multiplicator,
		       ref(resolution_domain),placeholders::_1,
		       component_direction(source_component)));
  
  gaussian_src_time src(freq_res,sigma,0.0*sigma,10.0*sigma);
  const volume srcvol(vec(0.,2.*center.y()-1.05*pml_thickness),
		      vec(2*center.x(),2.*center.y()-1.05*pml_thickness) );
  f.add_volume_source(source_component,src,srcvol,
		      bind(multiply_wrapper,amplitudefunc,phasefunc,
			   placeholders::_1),
		      1.0);
  f.output_hdf5(Dielectric,vol.surroundings());
  
  cout << "timestep dt: " << f.dt << endl;
  cout << "total time to do: " << f.last_source_time() << endl;

  int every_N=floor(0.5/(freq_res*f.dt));

  int counter(0);
  while (f.time() < f.last_source_time()){
    f.step();
    if (counter%every_N==0){
      f.output_hdf5(source_component,vol.surroundings());
      f.output_hdf5(Hx,vol.surroundings());
    }
    counter++;
  }

}
